price = 10  #Tipo de dato entero
rating = 4.9  #Tipo de dato flotante
name = 'David'  #Tipo de dato str
is_published = True  #Tipo de dato Booleano


print(price)
