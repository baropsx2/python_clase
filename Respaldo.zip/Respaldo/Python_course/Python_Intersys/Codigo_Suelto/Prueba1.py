def get_pais(letra):
    lista_pais = []
    for paises in letra.keys():
        print(letra)


#    for key, val in letra.items():
#        if key.startswith(key):
#            lista_pais.append(key)

#    print(lista_pais)
#    return lista_pais


codigos = {"Albania": 355,
           "Alemania": 49,
           "Mexico": 52
           }

get_pais("A")
get_pais("M")
