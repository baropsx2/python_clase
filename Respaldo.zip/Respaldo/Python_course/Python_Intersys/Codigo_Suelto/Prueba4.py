def agrega_pais(dic_codigos, pais, codigo):
    for k, v in dic_codigos:
        if k, v == dic_codigos:
            print(dic_codigos)


codigos = {"Albania": 355,
           "Alemania": 49,
           "Mexico": 52
           }


agrega_pais(codigos, "USA", 1)
