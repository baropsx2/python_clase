tupla = ('azul', 'rojo', 'amarillo')
for color in tupla:
    print(color)
