for varX in range(1, 20):
    if varX != 19:
        print("The following number is not 19")
    else:
        print("The next number it is!!")
    print(varX)
