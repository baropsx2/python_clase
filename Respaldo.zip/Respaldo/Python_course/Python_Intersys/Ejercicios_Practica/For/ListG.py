d = {
    'name': 'David',
    'age': 34,
    'telephone': 3331235468
}

for t in d.items():
    print(t)
