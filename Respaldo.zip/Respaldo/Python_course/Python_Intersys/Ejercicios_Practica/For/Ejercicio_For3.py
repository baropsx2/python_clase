for i in [0, 1, 2]:
    print(f"{i} * {i} = {i ** 2}")

a = dir(i)
print(a)

for i in [0, 1, 2, 3]:
    print(f"{i} * {i} * {i} = {i ** 3}")
