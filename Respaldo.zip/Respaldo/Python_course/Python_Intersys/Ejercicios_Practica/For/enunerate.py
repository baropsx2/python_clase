things = ('ball', 'water', 'clock', 'soda', 'food')

for item in enumerate(things):
    print(item)
