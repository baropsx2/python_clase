text = "This is a string that was written to validate a function"
result = text.startswith("This is a")
print(result)
resultTwo = text.endswith("function")
print(resultTwo)
resultThree = text.startswith("validate")
print(resultThree)
resultFour = text.endswith("written")
print(resultFour)