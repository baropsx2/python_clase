b = ["Hola mi nombre es: "]
c = ["David"]

for letter in c:
    if c == ["David"]:
        print(b + c)
    else:
        print("if is not returning the expected text")