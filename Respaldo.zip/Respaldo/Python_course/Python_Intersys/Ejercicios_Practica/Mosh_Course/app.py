print("Hello World 😊")
print("*" * 10)
x = 1
y = 2
unit_price = 3

students_count = 1000
rating = 4.99
is_published = False
course_name = """
Multiple
Lines
"""
# Ésto es equivalente al contenido del siguiente comentario
x = 1
y = 2

# Equivalente a lo de arriba
x, y = 1, 2
