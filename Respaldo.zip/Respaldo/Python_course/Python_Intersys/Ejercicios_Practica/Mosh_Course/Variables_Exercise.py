full_name = "John Smith"
age = 45
is_new = True

print(full_name)
print(age)
print(is_new)
